import glob
import os
import csv
import yaml
from pathlib import Path
import re
from ultralytics import YOLO
import torch 

def get_latest_run_directory(base_dir="./runs/"):
    """
    base_dir(기본 검색 경로) 안에서 'val', 'predict' 등을 제외한
    실제 *학습* 폴더 중 가장 최근의 폴더 경로를 반환합니다.
    """
    search_path = os.path.join(base_dir, '*/')
    all_dirs = glob.glob(search_path)
    
    train_dirs = [
        d for d in all_dirs 
        if 'val' not in os.path.basename(os.path.normpath(d)) and 
           'predict' not in os.path.basename(os.path.normpath(d))
    ]
    if not train_dirs:
        print(f"오류: '{base_dir}' 경로에서 'val' 또는 'predict'가 아닌 학습 폴더를 찾을 수 없습니다.")
        return None
        
    latest_dir = max(train_dirs, key=os.path.getmtime)
    latest_dir = os.path.normpath(latest_dir)
    
    print(f"가장 최신 *학습* 폴더를 찾았습니다: {latest_dir}")
    return latest_dir

def main():

    # 1. 학습 폴더(runs)의 기본 경로 (Windows)
    RUNS_BASE_PATH = r"Y:\Team2\AI_Team2\황정석\runs"

    # 2. Category ID 번역표
    CATEGORY_ID_MAP = [
        1899, 2482, 3350, 3482, 3543, 3742, 3831, 4377, 4542, 5093, 5885, 
        6191, 6562, 10220, 12080, 12246, 12419, 12777, 13394, 13899, 
        16231, 16261, 16547, 16550, 16687, 18109, 18146, 18356, 19231, 19551, 
        19606, 19860, 20013, 20237, 20876, 21025, 21324, 21770, 22073, 22346, 
        22361, 22626, 23202, 23222, 24849, 25366, 25437, 25468, 27652, 27732, 
        27776, 27925, 27992, 28762, 29344, 29450, 29666, 29870, 30307, 31704, 
        31862, 31884, 32309, 33008, 33207, 33877, 33879, 34596, 35205, 36636, 
        38161, 41767, 44198
    ]
    
    # 3. 최신 모델 로드
    latest_run_dir = get_latest_run_directory(base_dir=RUNS_BASE_PATH) 
    if latest_run_dir is None:
        return
        
    trained_model_path = os.path.join(latest_run_dir, 'weights/best.pt')
    if not os.path.exists(trained_model_path):
        trained_model_path = os.path.join(latest_run_dir, 'weights/last.pt')
        if not os.path.exists(trained_model_path):
            print(f"오류: {latest_run_dir}에서 'best.pt'와 'last.pt'를 모두 찾을 수 없습니다.")
            return
        print("'best.pt'를 못찾아서 'last.pt'를 대신 사용합니다.")

    print(f"모델 로드 중: {trained_model_path}")
    model = YOLO(trained_model_path)

    # 4. Test 이미지 경로 (Windows)
    TEST_IMAGE_DIR = r"Y:\Team2\AI_Team2\preprocess_bf\test_images"
    
    # 5. 파일 목록 로드, 필터링, 정렬
    print(f"\n'{TEST_IMAGE_DIR}' 폴더에서 이미지 파일을 검색 및 정렬합니다...")
    
    all_png_files = glob.glob(os.path.join(TEST_IMAGE_DIR, '*.png'))
    
    valid_image_list = []
    for image_path in all_png_files:
        filename = os.path.basename(image_path)
        
        if filename.startswith('._'):
            continue
            
        filename_stem = Path(filename).stem 
        
        if filename_stem.isdigit():
            image_id = int(filename_stem)
            valid_image_list.append((image_id, image_path))
        else:
            continue
            
    valid_image_list.sort(key=lambda x: x[0])
    
    if not valid_image_list:
        print(f"오류: '{TEST_IMAGE_DIR}' 폴더에서 유효한 (예: 1.png, 2.png) 이미지 파일을 찾을 수 없습니다.")
        return

    print(f"\n총 {len(valid_image_list)}개의 유효한 이미지를 정렬했습니다. 예측을 시작합니다.")
    
    # 6. CSV 준비 및 순차 예측 루프
    
    output_csv_path = os.path.join(latest_run_dir, 'submission_final_sorted.csv') 
    csv_header = ['annotation_id', 'image_id', 'category_id', 'bbox_x', 'bbox_y', 'bbox_w', 'bbox_h', 'score']
    
    annotation_id_counter = 1
 
    device_to_use = '0' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device_to_use}")

    with open(output_csv_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(csv_header)
        
        for image_id, image_path in valid_image_list:
            
            print(f"\n--- 💎 [ID: {image_id}] ({os.path.basename(image_path)}) 처리 중... ---")
            
            
            # --- ★★★ (핵심 수정) 예측 강화 옵션 추가 ★★★ ---
            results = model.predict(
                source=image_path, 
                device=device_to_use, 
                
                # [강화 1] Test-Time Augmentation (TTA)
                # True로 설정 시, 이미지를 좌우 반전(flip) / 크기 조절(scale)하여
                # 여러 번 예측한 뒤 그 결과를 종합(Ensemble)합니다.
                # 속도는 느려지지만, 예측 정확도와 안정성이 크게 향상됩니다.
                augment=True, 
                
                # [강화 2] Confidence Threshold (신뢰도 임계값)
                # 3_evaluate.py의 'F1_curve.png' 차트(plots=True 설정 시 생성됨)를 보고
                # F1 점수가 가장 높았던 최적의 conf 값으로 설정하는 것이 좋습니다.
                # (예: 0.25 -> 0.352 등으로 미세 조정)
                conf=0.25, 
                
                # [강화 3] IoU Threshold (NMS 임계값)
                # NMS(중복 제거) 시 사용할 IoU 값입니다.
                # 0.5 (50% 겹치면 중복) 또는 0.7 (70% 겹치면 중복) 등을 사용합니다.
                iou=0.5, 
                
                max_det=4
            )
            # --- ★★★ (수정 완료) ★★★ ---

            
            boxes = results[0].boxes
            
            if boxes.shape[0] == 0:
                print("  -> 객체를 찾지 못했습니다.")
                continue
                
            xyxy_list = boxes.xyxy.cpu().numpy()
            conf_list = boxes.conf.cpu().numpy()
            cls_list = boxes.cls.cpu().numpy().astype(int)

            for i in range(len(cls_list)):
                
                model_output_index = cls_list[i]
                
                if 0 <= model_output_index < len(CATEGORY_ID_MAP):
                    submission_category_id = CATEGORY_ID_MAP[model_output_index]
                else:
                    print(f"  -> (오류) 맵에 없는 클래스 인덱스({model_output_index})가 감지되어 건너뜁니다.")
                    continue 

                score = conf_list[i]
                
                x1, y1, x2, y2 = xyxy_list[i]
                bbox_x = x1
                bbox_y = y1
                bbox_w = x2 - x1
                bbox_h = y2 - y1
                
                print(f"  -> ✅ 발견: Category={submission_category_id}, Score={score:.4f}, BBox=[{bbox_x:.1f}, {bbox_y:.1f}, {bbox_w:.1f}, {bbox_h:.1f}]")
                
                writer.writerow([
                    annotation_id_counter, 
                    image_id,
                    submission_category_id,
                    round(bbox_x, 4), 
                    round(bbox_y, 4), 
                    round(bbox_w, 4), 
                    round(bbox_h, 4), 
                    round(score, 4)
                ])
                annotation_id_counter += 1

    print(f"\n\n🎉 예측 완료!")
    print(f"새로운 *정렬된* 제출용 CSV 파일이 다음 경로에 저장되었습니다: {output_csv_path}")

if __name__ == '__main__':
    main()