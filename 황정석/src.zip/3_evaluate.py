from ultralytics import YOLO
import glob  
import os    
import torch # torch 임포트

def get_model_path_from_file(txt_file_path):
    """
    [기능] txt_file_path (예: 'latest_model_path.txt') 파일을 읽어
           그 안에 저장된 'best.pt'의 절대 경로를 반환합니다.
    """
    # 1. .txt 파일 자체가 존재하는지 확인
    if not os.path.exists(txt_file_path):
        print(f"오류: '{txt_file_path}' 파일을 찾을 수 없습니다.")
        print("     -> 2_train.py (학습) 스크립트가 먼저 실행되어야 합니다.")
        return None
        
    # 2. .txt 파일의 내용을 읽어 경로(문자열)를 가져옴
    with open(txt_file_path, 'r', encoding='utf-8') as f:
        model_path = f.read().strip() # .strip()으로 공백/줄바꿈 제거
        
    # 3. .txt 파일에 적힌 경로에 'best.pt'가 실제로 존재하는지 확인
    if not os.path.exists(model_path):
        print(f"오류: '{txt_file_path}' 파일에 저장된 경로 '{model_path}'에")
        print("     'best.pt' 파일이 존재하지 않습니다.")
        return None
        
    print(f".txt 파일에서 모델 경로를 성공적으로 읽었습니다: {model_path}")
    return model_path

def main():
    
    # --- 1. 최신 모델 경로 파일 지정 ---
    # 2_train.py가 생성한 .txt 파일 경로
    LATEST_PATH_FILE = r"Y:\Team2\AI_Team2\latest_model_path.txt"
    # (만약 2_train.py와 3_evaluate.py가 같은 폴더(예: src)에 있다면)
    # LATEST_PATH_FILE = 'latest_model_path.txt' 

    # --- 2. 모델 경로 읽어오기 ---
    trained_model_path = get_model_path_from_file(LATEST_PATH_FILE)
    
    if trained_model_path is None:
        print("평가를 중단합니다.")
        return

    # --- 3. 데이터셋 YAML 경로 ---
    data_yaml_path = './data.yaml' 
    
    # --- 4. 학습된 모델 로드 ---
    print(f"Loading trained model from: {trained_model_path}")
    model = YOLO(trained_model_path)

    # --- 5. ★★★ (수정) 모델 성능 평가 기준 강화 ★★★ ---
    
    # [제어 1] IoU 임계값 (NMS 기준)
    # 모델이 예측한 박스들 중 겹치는 것을 제거(NMS)할 때 사용
    # (기본값 0.2, 0.5~0.7 등으로 조절)
    IOU_THRESHOLD = 0.5 
    
    # [제어 2] Confidence 임계값 (신뢰도 기준)
    # 모델이 '이 예측을 25% 이상 확신할 때만' 유효한 예측으로 간주
    # (None으로 두면 YOLO가 최적의 값을 자동으로 찾습니다.)
    CONF_THRESHOLD = 0.25 

    print(f"Evaluating model performance (IoU={IOU_THRESHOLD}, Conf={CONF_THRESHOLD})...")
    
    device_to_use = '0' if torch.cuda.is_available() else 'cpu'
    
    # 평가 결과를 'best.pt'가 있던 폴더(예: .../run_name_0) 내에 저장
    evaluation_save_dir = os.path.dirname(os.path.dirname(trained_model_path))

    metrics = model.val(
        data=data_yaml_path,
        device=device_to_use,
        split='val',           # 'val' 또는 'test' 데이터셋 사용
        
        # --- (강화된 평가 파라미터) ---
        
        iou=IOU_THRESHOLD,     # (조절) NMS IoU 임계값
        
        conf=CONF_THRESHOLD,   # (조절) 신뢰도 임계값
        
        # [추가] 시각화 차트(Confusion Matrix, PR Curve 등) 저장
        plots=True,            
        
        # [추가] COCO 형식의 .json 결과 파일 저장 (정밀 분석용)
        save_json=True,        
        
        project=evaluation_save_dir,
        name='evaluation_detailed' # (결과 저장 폴더 이름 변경)
    )
    
    # --- 6. mAP 값 추출 및 출력 ---
    print("\n--- Model Performance Metrics ---")
    
    # (plots=True로 저장된 차트 이미지 확인)
    print(f" ➡️ 상세 평가 차트(Confusion Matrix 등)가 저장되었습니다:")
    print(f"    {os.path.join(evaluation_save_dir, 'evaluation_detailed')}")
    
    # 
    # 혼동 행렬: 모델이 어떤 클래스를 어떤 클래스로 잘못 예측했는지 보여줍니다.
    
    # 
    # PR 곡선: 신뢰도(conf) 값의 변화에 따른 정밀도(Precision)와 재현율(Recall)의 관계를 보여줍니다.

    map50 = metrics.box.map50
    print(f"\nmAP@50 (IoU=0.5): {map50 * 100:.2f}%")
    
    map50_95 = metrics.box.map
    print(f"mAP@50-95 (Standard COCO): {map50_95 * 100:.2f}%")
    
    print("---------------------------------")

if __name__ == '__main__':
    main()