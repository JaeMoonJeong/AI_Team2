# 파일 이름: 2_train.py
from ultralytics import YOLO
import os
import torch 

def get_next_run_name(base_project_dir, base_run_name, max_versions=100):
    """
    [기능] 지정된 경로(base_project_dir)에서 
           기본 이름(base_run_name)을 확인하고,
           존재할 경우 _0, _1, ..._100 순서로 
           다음 버전의 폴더 이름을 찾아 반환합니다.
    """
    
    # 1. 기본 이름 (예: "pill_yolov8s_optimized") 자체를 먼저 확인
    base_path = os.path.join(base_project_dir, base_run_name)
    if not os.path.exists(base_path):
        return base_run_name # 기본 이름을 그대로 사용

    # 2. 기본 이름이 이미 존재하면, _0 부터 _100 까지 확인
    for i in range(max_versions + 1): # 0부터 100까지 (총 101회)
        versioned_name = f"{base_run_name}_{i}" # 예: "pill_yolov8s_optimized_0"
        versioned_path = os.path.join(base_project_dir, versioned_name)
        
        if not os.path.exists(versioned_path):
            return versioned_name # 비어있는 첫 번째 버전 이름을 반환

    # 3. 0부터 100까지 모든 폴더가 꽉 찼을 경우
    return None

def main():
    # 1. 모델 로드
    model = YOLO('yolov8s.pt') 

    # 2. 데이터셋 YAML 파일 경로
    data_yaml_path = 'data.yaml'

    # 3. GPU 설정
    device_to_use = '0' 
    if not torch.cuda.is_available():
        print("="*60)
        print("⚠️ 경고: CUDA 지원 GPU(NVIDIA)가 감지되지 않았습니다. CPU 모드로 전환합니다.")
        print("="*60)
        device_to_use = '0'
    else:
        print(f"✅ CUDA GPU 감지됨: {torch.cuda.get_device_name(0)}")

    # 4. ★★★ (수정) 경로 및 버전 관리 설정 ★★★
    
    # [설정 1] 결과를 저장할 기본 *프로젝트* 경로
    # 윈도우 경로는 r"..." (raw string) 또는 "Y:/.../" (슬래시)를 사용해야 합니다.
    BASE_PROJECT_PATH = r"Y:\Team2\AI_Team2\황정석\runs"
    
    # [설정 2] 이번 학습에 사용할 기본 *이름*
    BASE_RUN_NAME = "pill_yolov8s_optimized"

    # [실행] 위에서 정의한 헬퍼 함수를 호출하여 저장할 최종 폴더 이름을 결정
    final_run_name = get_next_run_name(BASE_PROJECT_PATH, BASE_RUN_NAME, max_versions=100)

    if final_run_name is None:
        print(f"❌ 오류: '{BASE_PROJECT_PATH}' 경로에")
        print(f"    '{BASE_RUN_NAME}'의 모든 버전 (0 ~ 100)이 이미 존재합니다.")
        print("    이전 결과 폴더를 삭제하거나 max_versions를 늘려주세요.")
        return
        
    print("\n" + "="*70)
    print(f"✅ 학습 준비 완료.")
    print(f" ➡️ 결과 저장 기본 경로 (Project): {BASE_PROJECT_PATH}")
    print(f" ➡️ 이번 실행 이름 (Name): {final_run_name}")
    print("="*70 + "\n")

    # 5. 모델 학습
    print("Starting model training with YOLOv8s...")
    
    results = None
    
    try:
        results = model.train(
            data=data_yaml_path,
            epochs=100,
            imgsz=640,
            batch=64,
            
            # ★★★ (수정) 위에서 결정된 경로와 이름을 적용 ★★★
            project=BASE_PROJECT_PATH,
            name=final_run_name, 
            
            device=device_to_use,
            
            # ★★★ (lr 제어) ★★★
            lr0=0.01,
            lrf=0.01,
            
            # --- 성능 최적화 파라미터 ---
            amp=True,
            workers=10,
            cos_lr=True,
            patience=50,
            
            # --- 데이터 증강 (Augmentation) 강화 ---
            flipud=0.5,
            fliplr=0.5,
            mixup=0.1,
            copy_paste=0.1,
            
            # --- 기타 설정 ---
            rect=False,
            val=True,
        )
    except RuntimeError as e:
        print("\n" + "="*80)
        print("❌ 런타임 오류 발생: 학습을 시작할 수 없습니다.")
        if "CUDA error: out of memory" in str(e):
            print("    [원인] GPU 메모리(VRAM) 부족. `batch` 사이즈를 16 또는 8로 줄이고 재시도하세요.")
        else:
            print(f"    [오류 내용] {e}")
        print("="*80)
        return
    except Exception as e:
        print("\n" + "="*80)
        print(f"❌ 알 수 없는 오류 발생: {e}")
        print("="*80)
        return

    print("Training complete.")

    # 6. (핵심) 검증 스크립트에서 사용할 경로 저장 (기존과 동일)
    #    (results.save_dir이 동적으로 결정된 경로를 참조하므로 수정 불필요)
    if results and hasattr(results, 'save_dir'):
        best_model_path = os.path.join(results.save_dir, 'weights/best.pt')
        output_path_file = 'latest_model_path.txt' 
        
        try:
            abs_model_path = os.path.abspath(best_model_path)
            with open(output_path_file, 'w', encoding='utf-8') as f:
                f.write(abs_model_path)
                
            print("\n" + "="*70)
            print("✅ 학습 완료! 최신 모델 경로를 파일에 저장했습니다.")
            print(f" ➡️ 가중치 경로: {abs_model_path}")
            print(f" ➡️ 저장된 파일: {os.path.abspath(output_path_file)}")
            print("="*70)

        except Exception as e:
            print(f"\n⚠️ 경고: '{output_path_file}' 파일 저장 실패: {e}")
            print(f"Best model weights saved to: {best_model_path}")
    else:
        print("\n⚠️ 경고: 학습 결과(results) 객체를 찾을 수 없어 모델 경로를 저장하지 못했습니다.")

if __name__ == '__main__':
    main()